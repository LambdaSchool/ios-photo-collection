//
//  Photo.swift
//  Photo Collection
//
//  Created by William Chen on 8/22/19.
//  Copyright © 2019 William Chen. All rights reserved.
//

import Foundation

struct  Photo:Equatable {
    var imageData: Data
    var title: String
    
}
